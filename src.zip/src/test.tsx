import React from 'react'

const test = () => {
  return (
    <div>
      <h1 className='text-red-500'>Ashvini</h1>
    </div>
  )
}

export default test
