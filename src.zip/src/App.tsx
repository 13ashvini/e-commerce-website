import PageRouting from './PageRouting'

const App = () => {
  return (
    <div>
    <PageRouting/>
    </div>
  )
}

export default App
