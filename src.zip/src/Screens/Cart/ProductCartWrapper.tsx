import React from 'react'

type Props = {}

const ProductCartWrapper = (props: Props) => {
  return (
    <div>ProductCartWrapper</div>
  )
}

export default ProductCartWrapper